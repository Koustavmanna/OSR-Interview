from fastapi import FastAPI
from app.routes.osr import router as osr_router

app = FastAPI(
    title="AI-Powered OSR Model Builder",
    description="Generates structured OSR models using LLMs",
    version="1.0.0",
)

app.include_router(osr_router)
