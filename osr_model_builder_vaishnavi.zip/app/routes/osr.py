from fastapi import APIRouter, HTTPException
from app.models.schemas import OSRRequest, OSRResponse
from app.services.llm_service import generate_osr
from app.utils.parser import parse_llm_output
from pathlib import Path

router = APIRouter()
PROMPT_PATH = Path("app/prompts/osr_prompt.txt")

@router.post("/generate-osr", response_model=OSRResponse)
def generate_osr_model(request: OSRRequest):
    if not request.description.strip():
        raise HTTPException(status_code=400, detail="Description cannot be empty")

    prompt_template = PROMPT_PATH.read_text()

    try:
        llm_output = generate_osr(request.description, prompt_template)
        parsed_output = parse_llm_output(llm_output)
        return parsed_output
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception:
        raise HTTPException(status_code=500, detail="OSR generation failed")
