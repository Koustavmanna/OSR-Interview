import json

REQUIRED_KEYS = {
    "primaryOutcome",
    "performanceTargets",
    "supportOutcomes",
    "flowRates",
    "milestones",
}

def parse_llm_output(output: str) -> dict:
    try:
        data = json.loads(output)
    except json.JSONDecodeError:
        raise ValueError("LLM returned invalid JSON")

    if not isinstance(data, dict):
        raise ValueError("JSON root must be an object")

    missing = REQUIRED_KEYS - data.keys()
    if missing:
        raise ValueError(f"Missing required keys: {missing}")

    return data
